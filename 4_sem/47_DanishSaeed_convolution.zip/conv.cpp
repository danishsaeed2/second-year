#include<iostream>
using namespace std;

int main()
{
	int a[30],b[30],c[80];
	int an,bn,i,j,sa,sb,sc;
	
	cout<<"\nNumber of input values in signal x[n]: ";
	cin>>an;
	cout<<"Number of input values in signal h[n]: ";
	cin>>bn;
	
	cout<<"\nStarting index of x[n]: ";
	cin>>sa;
	cout<<"Starting index of h[n]: ";
	cin>>sb;
	
	cout<<"\nEnter signal x[n]: "<<endl;
	for (i=0;i<an;i++)
	{
		cout<<"Value "<<sa+i<<" : ";
		cin>>a[i];
	}
	
	cout<<"\nEnter signal h[n]: "<<endl;
	for (i=0;i<bn;i++)
	{
		cout<<"Value "<<sb+i<<" : ";
		cin>>b[i];
	}
	
	for (i=an;i<=an+bn-1;i++)
	{
		a[i]=0;
	}
	for (i=bn;i<=an+bn-1;i++)
	{
		b[i]=0;
	}
	
	for (i=0;i<an+bn-1;i++)
	{
		c[i]=0;
		for (j=0;j<=i;j++)
		{
			c[i]=c[i]+(a[j]*b[i-j]);
		}
	}
	
	sc=sa+sb;
	
	for (i=0;i<an+bn-1;i++)
	{
		cout<<"\nThe value of output y["<<sc+i<<"] : "<<c[i];
	}
	cout<<endl<<endl;
	return 0;
	
}
