#include<iostream>
#include<cmath>
#include<complex>

using namespace std;

void ifft (float *ar, float *img, int x);
void merge (float *ar, float *img, float *br, float *cr, int x);

void merge (float *ar, float *img, float *br, float *cr, int x)
{
	float t=2*3.1416/(x);
	int a,b;
	int i;
	for(i=0;i<x/2;i++)
	{
		a=cos(t*i);
		b=sin(-t*i);
		ar[i]=br[i] + a*cr[i];
		img[i]=b*cr[i];
		ar[i+x/2]=br[i] - a*cr[i];
		img[i+x/2]= - b*cr[i];
	}
}
 
void ifft (float *ar, float *img, int x)
{
	if(x==1)
	{
		return;
	}
	int j=0,k=0;
	float br[x/2],cr[x/2];
	while(j<x)
	{
		br[k]=ar[j];
		k++;
		j+=2;
	}
	k=0;
	j=1;
	while(j<x)
	{
		cr[k]=ar[j];
		k++;
		j+=2;
	}
	ifft(br,img,x/2);
	ifft(cr,img,x/2);
	merge(ar,img,br,cr,x);
}

int main()
{
	int N;
	cout<<"\n\nInverse Discrete Fourier Transform using FFT\n";
	cout<<"\nEnter number of input samples in X[n]: ";
	cin>>N;
	float a[N],b[N],imga[N],imgb[N];
	int i;
	for(i=0;i<N;i++)
	{
		cout<<"\nX["<<i<<"] real= ";
		cin>>b[i];
		cout<<"X["<<i<<"] imag= ";
		cin>>a[i];
		b[i]=-b[i];
		imga[i]=0;
	}
	ifft(a,imga,N);
	ifft(b,imgb,N);
	cout<<"\nThe IDFT of given sequence is:\n";
	for(i=0;i<N;i++)
	{
		cout<<"X("<<i<<")= ";
		cout<<(-b[i]+imga[i])/N <<" + "<<(a[i]-imgb[i])/N<<"i"<<endl  ;
	}
	cout<<endl<<endl;
	return 0;
}
