#include<iostream>
#include<cmath>
#include<complex>

using namespace std;

void fft (float *ar, float *img, int x);
void merge (float *ar, float *img, float *br, float *cr, int x);

void merge (float *ar, float *img, float *br, float *cr, int x)
{
	float t=2*3.1416/(x);
	float  a;
	float  b;
	int i;
	
	for(i=0;i<x/2;i++)
	{
		a=cos(t*(float)i);
		b=sin(-t*(float)i);
		ar[i]=br[i] + a*cr[i];
		img[i]=b*cr[i];
		ar[i+x/2]=br[i] - a*cr[i];
		img[i+x/2]= - b*cr[i];
	}
}

void fft (float *ar, float *img, int x)
{
	if(x==1)
	{
		return;
	}
	int j=0,k=0;
	float br[x/2],cr[x/2];
	while(j<x)
	{
		br[k]=ar[j];
		k++;
		j+=2;
	}
	k=0;
	j=1;
	while(j<x)
	{
		cr[k]=ar[j];
		k++;
		j+=2;
	}
	fft(br,img,x/2);
	fft(cr,img,x/2);
	merge(ar,img,br,cr,x);
}

int main()
{
	int N;
	cout<<"\n\nDiscrete Fourier Transform using FFT\n";
	cout<<"\nEnter number of input samples in X[n]: ";
	cin>>N;
	float ar[N],img[N];
	int i;
	for(i=0;i<N;i++)
	{
		img[i]=0;
		cout<<"X["<<i<<"]= ";
		cin>>ar[i];
	}
	fft(ar,img,N);
	cout<<"\nThe DFT of given sequence is:\n";
	for(i=0;i<N;i++)
	{
		cout<<"X("<<i<<")= ";
		cout<<ar[i]<<" + "<<img[i]<<"i"<<endl  ;
	}
	cout<<endl<<endl;
	return 0;
}
