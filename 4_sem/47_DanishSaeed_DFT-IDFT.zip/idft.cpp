#include<iostream>
#include<cmath>

#define PI 3.1416

using namespace std;

int main ()
{
	int n,k,N;
	cout<<"\n\nInverse Discrete Fourier Transform\n";
	cout<<"\nEnter number of input samples in X[n]: ";
	cin>>N;
	
	float X[N],Xreal[N],Ximag[N];
	
	cout<<"\nEnter the samples:\n";
	for (n=0;n<N;n++)
	{
		cout<<"\nX["<<n<<"] real= ";
		cin>>Xreal[n];
		cout<<"X["<<n<<"] imag= ";
		cin>>Ximag[n];
	}
	
	for (n=0;n<N;n++)
	{
		X[n]=0;
		for (k=0;k<N;k++)
		{
			X[n]=X[n] + Xreal[k]*cos((2*PI*k*n)/N) - Ximag[k]*sin((2*PI*k*n)/N);
		}
		X[n]=X[n]/N;
	}
	
	cout<<"\nThe IDFT of given sequence is:";
	for (n=0;n<N;n++)
	{
		cout<<"\nX("<<n<<")= "<<X[n];
	}
	cout<<endl<<endl;
	
	return 0;
}
