#include<iostream>
#include<cmath>

#define PI 3.1416

using namespace std;

int main ()
{
	int n,k,N;
	cout<<"\n\nDiscrete Fourier Transform\n";
	cout<<"\nEnter number of input samples in X[n]: ";
	cin>>N;
	
	float X[N],Xreal[N],Ximag[N];
	
	cout<<"\nEnter the samples:\n";
	for (n=0;n<N;n++)
	{
		cout<<"X["<<n<<"]= ";
		cin>>X[n];
	}
	
	for (k=0;k<N;k++)
	{
		Xreal[k]=Ximag[k]=0;
		for (n=0;n<N;n++)
		{
			Xreal[k]=Xreal[k] + X[n]*cos((n*k*2*PI)/N);
			Ximag[k]=Ximag[k] + X[n]*sin((n*k*2*PI)/N);
		}
		Ximag[k]=Ximag[k]*(-1.0);
	}
	
	cout<<"\nThe "<<N<<" point DFT of given sequence is:";
	cout<<"\n\tReal X[k]\tImaginary X[k]\n";
	for (k=0;k<N;k++)
	{
		cout<<"\nX("<<k<<")= "<<Xreal[k]<<"\t\t"<<Ximag[k]<<"\t\t";
	}
	cout<<endl<<endl;
	
	return 0;
}
